#!/bin/sh

echo "==================================="
echo "Starting DB dump"

./dbdump-internal.sh > dbdump.log 2>&1

if [ $? -eq 0 ]; then
  echo "==================================="
  echo "SUCCESS: DB dump complete"
  echo "==================================="
  exit 0
else
  echo "==================================="
  echo "ERROR:   DB dump failed"
  echo "==================================="
  exit 1
fi
