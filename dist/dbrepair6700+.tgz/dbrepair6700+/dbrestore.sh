#!/bin/sh

echo "==================================="
echo "Starting DB restore"

./dbrestore-internal.sh > dbrestore.log 2>&1

if [ $? -eq 0 ]; then
  echo "==================================="
  echo "SUCCESS: DB restore complete"
  echo "==================================="
  exit 0
else
  echo "==================================="
  echo "ERROR:   DB restore failed"
  echo "==================================="
  exit 1
fi
