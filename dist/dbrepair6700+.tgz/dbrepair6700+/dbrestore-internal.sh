#!/bin/sh

echo "=== $(date) $0 started =========="

. db.ini

result()
{
	if [ $? -ne 0 ]; then
		echo "ERROR"
		exit 1
	fi
}
echo
echo "Executing $GRANTS_FILE"
mysql --host=$DBHOST --user=$DBUSER --execute="source $GRANTS_FILE"
result

echo
echo "Executing $DBBACKUPFILE"
mysql --host=$DBHOST --user=$DBUSER --password=$DBPASSWORD --execute="source $DBBACKUPFILE"
result


echo "=== $(date) $0 completed =========="
exit 0
