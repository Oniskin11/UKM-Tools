#!/bin/sh

echo "=== $(date) $0 started ============"

. db.ini

echo "SET FOREIGN_KEY_CHECKS = 0;" > $DBBACKUPFILE
echo "CREATE DATABASE $DBNAME;" >> $DBBACKUPFILE
echo "use $DBNAME;" >> $DBBACKUPFILE

echo "Db backup file is $DBBACKUPFILE"
echo "Starting mysqldump"
mysqldump --opt --routines --triggers --skip-add-drop-table --user=$DBUSER --host=$DBHOST --password=$DBPASSWORD --databases $DBNAME >> $DBBACKUPFILE
exit_code=$?
echo "mysqldump exit code = $exit_code"
echo
echo "=== $(date) $0 completed =========="

exit $exit_code
