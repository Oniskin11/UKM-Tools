#!/bin/sh

LOGFILE=dbrepair.log

. db.ini > $LOGFILE

echo "======================================="
echo "Starting repair of database $DBNAME ..."

echo " " >> $LOGFILE
echo "===========================================" >> $LOGFILE
echo `date` >> $LOGFILE
ifconfig eth0 >> $LOGFILE
echo "===========================================" >> $LOGFILE

mysqlcheck --host=$DBHOST --user=$DBUSER --password=$DBPASSWORD --check --auto-repair --default-character-set=utf8 --verbose --force $DBNAME >> $LOGFILE 2>&1

if [ $? -eq 0 ]; then
	echo "==================================="
	echo "Database repair complete"
	echo "Check log $LOGFILE"
	echo "==================================="
	echo "Press any key"
	read
	exit 0
else
	echo "==================================="
	echo "ERROR:  Database repair failed"
	echo "Check log $LOGFILE"
	echo "==================================="
	echo "Press any key"
	read
	exit 1
fi