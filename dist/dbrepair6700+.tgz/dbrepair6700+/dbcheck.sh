#!/bin/sh

LOGFILE=dbcheck.log

. db.ini > $LOGFILE



echo "======================================="
echo "Starting check of database $DBNAME..."

echo " " >> $LOGFILE
echo "===========================================" >> $LOGFILE
echo `date` >> $LOGFILE
ifconfig eth0 >> $LOGFILE
echo "===========================================" >> $LOGFILE

mysqlcheck --host=$DBHOST --user=$DBUSER --password=$DBPASSWORD --check --default-character-set=utf8 --verbose $DBNAME >> $LOGFILE 2>&1

if [ $? -eq 0 ]; then
	echo "======================================="
	echo "Database check complete"
	echo "Check result file $LOGFILE"
	echo "======================================="
	echo "Press any key"
	read
	exit 0
else
	echo "======================================="
	echo "ERROR:  database check failed"
	echo "Check result file $LOGFILE"
	echo "======================================="
	echo "Press any key"
	read
	exit 1
fi